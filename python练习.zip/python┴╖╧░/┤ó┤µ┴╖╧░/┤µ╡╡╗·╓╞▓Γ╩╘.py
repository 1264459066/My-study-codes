with open("save.ini", "r") as file:
    a = file.readline()
    b = file.readline()
    c = file.readline()
#读取

a = int(a[0:2]) #a="1\n"; a[0:2]="1"; int(a[0:2])=1
b = int(b[0:2]) #same ↑
c = int(c)

x = input("输入a,全体+10 or 全体-10")
if x == 'a':   
    a += 10
    b += 10
    c += 10
else:
    a -= 10
    b -= 10
    c -= 10

print(a, b, c)
print("已储存到save.ini文件")

with open("save.ini", "w") as file:
    a = str(a)
    b = str(b)
    c = str(c)
    file.write(a+"\n")
    file.write(b+"\n")
    file.write(c)
#写入