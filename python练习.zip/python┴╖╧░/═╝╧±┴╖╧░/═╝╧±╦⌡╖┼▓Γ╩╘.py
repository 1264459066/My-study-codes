import pygame
import sys
from pygame.locals import *

pygame.init()
size = width, height = 1920, 1080
screen = pygame.display.set_mode(size)
img = pygame.image.load("bg_image.png")
img2 = pygame.transform.scale(img, size)#重点：缩放后的图像 = pygame.transform.scale(原图像, 缩放尺寸)
screen.blit(img2, (0, 0))

while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    pygame.display.flip()


